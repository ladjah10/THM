// This file contains utility functions to prevent screenshots and printing

// Add watermark to the page
export const addWatermark = () => {
  // Create watermark container
  const watermarkContainer = document.createElement('div');
  watermarkContainer.className = 'watermark-container';
  
  // Create watermark text
  const watermarkText = document.createElement('div');
  watermarkText.className = 'watermark-text';
  watermarkText.innerText = '© 2025 Lawrence E. Adjah - Do Not Copy';
  
  // Append watermark to container
  watermarkContainer.appendChild(watermarkText);
  
  // Append container to body
  document.body.appendChild(watermarkContainer);
  
  // Add CSS for watermark
  const style = document.createElement('style');
  style.textContent = `
    .watermark-container {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 1000;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }
    
    .watermark-text {
      transform: rotate(-45deg);
      font-size: 60px;
      color: rgba(200, 200, 200, 0.2);
      white-space: nowrap;
      user-select: none;
      pointer-events: none;
      position: absolute;
      width: 100%;
      text-align: center;
    }
  `;
  document.head.appendChild(style);
};

// Prevent keyboard shortcuts for screenshots and printing
export const preventScreenshotShortcuts = (e) => {
  // Prevent PrintScreen and other common screenshot/print shortcuts
  if (
    (e.key === 'PrintScreen') || 
    (e.ctrlKey && e.key === 'p') || 
    (e.ctrlKey && e.shiftKey && e.key === 'p') ||
    (e.ctrlKey && e.key === 's') ||
    (e.metaKey && e.key === 'p') ||
    (e.metaKey && e.shiftKey && e.key === 'p') ||
    (e.metaKey && e.key === 's')
  ) {
    e.preventDefault();
    alert('Printing and screenshots are disabled for this assessment.');
    return false;
  }
};

// Prevent right-click context menu
export const preventRightClick = (e) => {
  e.preventDefault();
  return false;
};

// Prevent text selection
export const preventTextSelection = () => {
  const style = document.createElement('style');
  style.textContent = `
    body {
      user-select: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
    }
  `;
  document.head.appendChild(style);
};

// Detect and block browser developer tools
export const detectDevTools = () => {
  // Function to check if dev tools are open
  const checkDevTools = () => {
    const widthThreshold = window.outerWidth - window.innerWidth > 160;
    const heightThreshold = window.outerHeight - window.innerHeight > 160;
    
    if (widthThreshold || heightThreshold) {
      alert('Developer tools detected. Please close developer tools to continue using the assessment.');
    }
  };
  
  // Check periodically
  setInterval(checkDevTools, 1000);
  
  // Also check on resize
  window.addEventListener('resize', checkDevTools);
};

// Initialize all protection measures
export const initializeProtection = () => {
  // Add watermark
  addWatermark();
  
  // Prevent text selection
  preventTextSelection();
  
  // Add event listeners
  document.addEventListener('keydown', preventScreenshotShortcuts);
  document.addEventListener('contextmenu', preventRightClick);
  
  // Detect dev tools
  detectDevTools();
  
  // Disable browser's native print functionality
  window.addEventListener('beforeprint', (e) => {
    e.preventDefault();
    alert('Printing is disabled for this assessment.');
    return false;
  });
  
  console.log('Screenshot and print protection initialized');
};

// Clean up protection measures
export const cleanupProtection = () => {
  document.removeEventListener('keydown', preventScreenshotShortcuts);
  document.removeEventListener('contextmenu', preventRightClick);
  window.removeEventListener('resize', detectDevTools);
  
  // Remove watermark if it exists
  const watermark = document.querySelector('.watermark-container');
  if (watermark) {
    watermark.remove();
  }
  
  console.log('Screenshot and print protection cleaned up');
};
