import axios from 'axios';

// Calculate scores based on user responses and question weights
export const calculateScores = (answers, questions) => {
  // Initialize results object
  const results = {
    totalScore: 0,
    maxPossibleScore: 0,
    sectionScores: {},
    responses: []
  };

  // Process each question
  questions.forEach(question => {
    // Initialize section if it doesn't exist
    if (!results.sectionScores[question.section]) {
      results.sectionScores[question.section] = {
        total: 0,
        max: 0
      };
    }

    // Get user's answer for this question
    const userAnswer = answers[question.id];
    
    // Calculate score for this question
    let score = 0;
    if (userAnswer) {
      // For multiple choice questions, score is based on the selected option
      if (question.type === 'M') {
        // First option is considered the "best" answer and gets full points
        // Other options get decreasing points
        const optionIndex = question.options.indexOf(userAnswer);
        if (optionIndex === 0) {
          score = question.weight;
        } else {
          // Decrease score based on option position
          score = Math.max(0, question.weight - (optionIndex * (question.weight / question.options.length)));
        }
      } 
      // For declaration questions, if they selected the option, they get full points
      else if (question.type === 'D') {
        score = question.weight;
      }
    }

    // Add to total scores
    results.totalScore += score;
    results.maxPossibleScore += question.weight;
    
    // Add to section scores
    results.sectionScores[question.section].total += score;
    results.sectionScores[question.section].max += question.weight;

    // Add response details
    results.responses.push({
      questionId: question.id,
      questionText: question.text,
      answer: userAnswer || 'No answer',
      weight: question.weight,
      score: score
    });
  });

  // Calculate percentages for each section
  Object.keys(results.sectionScores).forEach(section => {
    const sectionData = results.sectionScores[section];
    sectionData.percentage = Math.round((sectionData.total / sectionData.max) * 100);
  });

  return results;
};

// Submit questionnaire results to the backend
export const submitQuestionnaire = async (demographicAnswers, answers, questions) => {
  try {
    // Calculate scores
    const results = calculateScores(answers, questions);
    
    // Add demographic information
    results.demographics = demographicAnswers;
    
    // Submit to backend
    const response = await axios.post('/api/questionnaire/submit', results);
    
    return {
      success: true,
      results: response.data || results
    };
  } catch (error) {
    console.error('Error submitting questionnaire:', error);
    return {
      success: false,
      error: error.message || 'Failed to submit questionnaire'
    };
  }
};

// Get matching profiles based on questionnaire results
export const getMatches = async (results) => {
  try {
    const response = await axios.post('/api/matching/find', { results });
    return {
      success: true,
      matches: response.data
    };
  } catch (error) {
    console.error('Error getting matches:', error);
    return {
      success: false,
      error: error.message || 'Failed to get matches'
    };
  }
};
