import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Button, 
  Typography, 
  Container, 
  Paper,
  CircularProgress,
  Alert,
  Card,
  CardContent,
  Stack,
  Divider,
  List,
  ListItem,
  ListItemText
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Matches: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [matches, setMatches] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);
  
  const navigate = useNavigate();
  
  // Check if user is logged in
  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!isLoggedIn) {
      navigate('/login');
      return;
    }
    
    // Load user data and calculate matches
    try {
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      const allUsers = JSON.parse(localStorage.getItem('users') || '[]');
      
      // Get user's profile based on score and gender
      const userProfile = getProfileForUser(currentUser);
      setProfile(userProfile);
      
      // Find potential matches (opposite gender)
      const potentialMatches = allUsers.filter((user: any) => {
        return user.id !== currentUser.id && user.gender !== currentUser.gender;
      });
      
      // Apply hard filters
      const filteredMatches = potentialMatches.filter((match: any) => {
        // Faith filter
        if (currentUser.faith === 'believe_in_christ' && match.faith !== 'believe_in_christ') {
          return false;
        }
        
        // Children filter
        if (currentUser.wantsChildren === 'yes' && match.wantsChildren === 'no') {
          return false;
        }
        if (currentUser.wantsChildren === 'no' && match.wantsChildren === 'yes') {
          return false;
        }
        
        return true;
      });
      
      // Calculate score differences and sort by proximity
      const matchesWithScores = filteredMatches.map((match: any) => {
        const scoreDifference = Math.abs((currentUser.totalScore || 500) - (match.totalScore || 500));
        const matchProfile = getProfileForUser(match);
        
        return {
          ...match,
          scoreDifference,
          profile: matchProfile.name,
          compatibility: calculateCompatibility(scoreDifference)
        };
      });
      
      // Sort by score proximity
      matchesWithScores.sort((a: any, b: any) => a.scoreDifference - b.scoreDifference);
      
      setMatches(matchesWithScores);
    } catch (err) {
      console.error('Error loading matches:', err);
      setError('Failed to load matches. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [navigate]);
  
  // Calculate compatibility percentage based on score difference
  const calculateCompatibility = (scoreDifference: number) => {
    // Max difference is 1000, so we invert and scale to percentage
    return Math.max(0, Math.min(100, 100 - (scoreDifference / 10)));
  };
  
  // Get profile based on score and gender
  const getProfileForUser = (user: any) => {
    const score = user.totalScore || 500;
    const gender = user.gender || 'other';
    
    let profile = {
      name: 'Undefined Profile',
      description: 'Profile not found',
      key_traits: ['Undefined'],
      strengths: ['Undefined'],
      weaknesses: ['Undefined']
    };
    
    if (gender === 'female') {
      if (score > 700) {
        profile = {
          name: 'Relational Nurturer',
          description: "You prioritize deep emotional connections and care deeply about others' wellbeing.",
          key_traits: ['Empathetic', 'Supportive', 'Faith-centered'],
          strengths: ['Building strong relationships', 'Creating harmonious environments', 'Emotional intelligence'],
          weaknesses: ['May neglect own needs', 'Can be overly accommodating', 'Might avoid necessary conflict']
        };
      } else if (score > 500) {
        profile = {
          name: 'Adaptive Communicator',
          description: 'You excel at expressing yourself and adapting to different social situations.',
          key_traits: ['Articulate', 'Flexible', 'Socially aware'],
          strengths: ['Clear communication', 'Conflict resolution', 'Building consensus'],
          weaknesses: ['May change positions to please others', 'Can be indecisive', 'Might avoid difficult truths']
        };
      } else {
        profile = {
          name: 'Independent Traditionalist',
          description: 'You value self-reliance while maintaining respect for established traditions.',
          key_traits: ['Self-sufficient', 'Principled', 'Structured'],
          strengths: ['Personal accountability', 'Clear boundaries', 'Consistency'],
          weaknesses: ['May resist necessary change', 'Can be overly rigid', 'Might struggle with vulnerability']
        };
      }
    } else if (gender === 'male') {
      if (score > 700) {
        profile = {
          name: 'Faithful Protector',
          description: 'You are dedicated to safeguarding those you care about, guided by strong faith principles.',
          key_traits: ['Loyal', 'Principled', 'Protective'],
          strengths: ['Providing security', 'Moral leadership', 'Dependability'],
          weaknesses: ['May be overprotective', 'Can be inflexible on values', 'Might struggle with expressing emotions']
        };
      } else if (score > 500) {
        profile = {
          name: 'Structured Leader',
          description: 'You thrive on creating order and providing direction for yourself and others.',
          key_traits: ['Organized', 'Decisive', 'Goal-oriented'],
          strengths: ['Strategic thinking', 'Efficient problem-solving', 'Clear direction'],
          weaknesses: ['May be controlling', 'Can overlook emotional factors', 'Might be impatient with process']
        };
      } else {
        profile = {
          name: 'Pragmatic Partner',
          description: 'You take a practical approach to relationships, focusing on tangible results and mutual benefit.',
          key_traits: ['Practical', 'Straightforward', 'Solution-focused'],
          strengths: ['Problem-solving', 'Resourcefulness', 'Adaptability'],
          weaknesses: ['May seem emotionally detached', 'Can be too focused on practicality', 'Might avoid deeper emotional topics']
        };
      }
    } else {
      // Unisex profiles
      if (score > 700) {
        profile = {
          name: 'Steadfast Believer',
          description: 'You have unwavering faith that guides all aspects of your life and relationships.',
          key_traits: ['Devoted', 'Consistent', 'Principled'],
          strengths: ['Strong moral compass', 'Reliability', 'Deep commitment'],
          weaknesses: ['May judge others by strict standards', 'Can be inflexible', 'Might struggle with different perspectives']
        };
      } else if (score > 500) {
        profile = {
          name: 'Harmonious Planner',
          description: 'You seek balance and thoughtfully prepare for the future in all areas of life.',
          key_traits: ['Balanced', 'Forward-thinking', 'Considerate'],
          strengths: ['Creating stability', 'Long-term vision', 'Thoughtful decision-making'],
          weaknesses: ['May overthink decisions', 'Can be anxious about uncertainty', 'Might resist spontaneity']
        };
      } else {
        profile = {
          name: 'Flexible Faithful',
          description: 'You maintain core faith values while adapting to life\'s changing circumstances.',
          key_traits: ['Adaptable', 'Grounded', 'Open-minded'],
          strengths: ['Navigating change', 'Inclusive approach to faith', 'Finding middle ground'],
          weaknesses: ['May seem inconsistent to others', 'Can struggle with firm positions', 'Might avoid deeper theological questions']
        };
      }
    }
    
    return profile;
  };

  return (
    <Container maxWidth="md">
      <Paper elevation={3} sx={{ p: 4, mt: 8, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Your Matches
        </Typography>
        
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            {profile && (
              <Box sx={{ mb: 4 }}>
                <Typography variant="h5" gutterBottom>
                  Your Profile: {profile.name}
                </Typography>
                <Typography variant="body1" paragraph>
                  {profile.description}
                </Typography>
                
                <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ mt: 2 }}>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="subtitle1" fontWeight="bold">Key Traits:</Typography>
                    <List dense>
                      {profile.key_traits.map((trait: string, index: number) => (
                        <ListItem key={index}>
                          <ListItemText primary={trait} />
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="subtitle1" fontWeight="bold">Strengths:</Typography>
                    <List dense>
                      {profile.strengths.map((strength: string, index: number) => (
                        <ListItem key={index}>
                          <ListItemText primary={strength} />
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="subtitle1" fontWeight="bold">Growth Areas:</Typography>
                    <List dense>
                      {profile.weaknesses.map((weakness: string, index: number) => (
                        <ListItem key={index}>
                          <ListItemText primary={weakness} />
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                </Stack>
                
                <Divider sx={{ my: 3 }} />
              </Box>
            )}
            
            <Typography variant="h5" gutterBottom>
              Compatible Matches
            </Typography>
            
            {matches.length === 0 ? (
              <Alert severity="info">No matches found based on your criteria. Try adjusting your preferences.</Alert>
            ) : (
              <Stack spacing={3}>
                {matches.map((match, index) => (
                  <Card key={match.id || index}>
                    <CardContent>
                      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
                        <Box sx={{ flex: 2 }}>
                          <Typography variant="h6" gutterBottom>
                            {match.email}
                          </Typography>
                          <Typography variant="body2" color="text.secondary" paragraph>
                            Profile: {match.profile}
                          </Typography>
                          <Typography variant="body2">
                            Faith: {match.faith === 'believe_in_christ' ? 'Believes in Christ' : 
                                   match.faith === 'plan_to_accept' ? 'Plans to accept Christ' : 'Other'}
                          </Typography>
                          <Typography variant="body2">
                            Wants Children: {match.wantsChildren === 'yes' ? 'Yes' : 
                                            match.wantsChildren === 'no' ? 'No' : 'Undecided'}
                          </Typography>
                        </Box>
                        <Box sx={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="h4" color="primary" fontWeight="bold">
                              {Math.round(match.compatibility)}%
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              Compatibility
                            </Typography>
                          </Box>
                        </Box>
                      </Stack>
                    </CardContent>
                  </Card>
                ))}
              </Stack>
            )}
          </>
        )}
      </Paper>
    </Container>
  );
};

export default Matches;
