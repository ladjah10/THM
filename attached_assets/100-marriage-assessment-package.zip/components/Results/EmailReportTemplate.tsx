const generateEmailReport = (results) => {
  // Extract profile from results if it exists
  const profile = results.profile || null;
  
  // Create HTML email template with simpler structure to avoid syntax errors
  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Your 100 Marriage Assessment Results</title>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #8884d8; padding-bottom: 20px; }
    .section { margin-bottom: 30px; padding: 20px; background-color: #f9f9f9; border-radius: 5px; }
    .score-item { display: flex; justify-content: space-between; margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
    .score-bar { height: 20px; background-color: #8884d8; margin-top: 5px; }
    .profile-section { background-color: #f0f0ff; padding: 20px; border-radius: 5px; margin-bottom: 30px; }
    .profile-name { font-size: 24px; font-weight: bold; color: #5151a2; margin-bottom: 10px; }
    .profile-description { margin-bottom: 15px; }
    .characteristics-list { padding-left: 20px; }
    .response-item { margin-bottom: 20px; padding: 15px; background-color: #f5f5f5; border-radius: 5px; }
    .question-text { font-weight: bold; margin-bottom: 5px; }
    .answer-text { color: #5151a2; margin-bottom: 5px; }
    .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #777; }
    .scale { display: flex; justify-content: space-between; margin: 10px 0; }
    .scale-item { text-align: center; font-size: 12px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>Your 100 Marriage Assessment Results</h1>
    <p>Assessment Date: ${new Date().toLocaleDateString()}</p>
  </div>
  
  <div class="section">
    <h2>Personal Information</h2>
    <div class="score-item">
      <span>Name:</span>
      <span>${results.demographics?.firstName || ''} ${results.demographics?.lastName || ''}</span>
    </div>
    <div class="score-item">
      <span>Email:</span>
      <span>${results.demographics?.email || ''}</span>
    </div>
    <div class="score-item">
      <span>Gender:</span>
      <span>${results.demographics?.gender || ''}</span>
    </div>
    <div class="score-item">
      <span>Marriage Status:</span>
      <span>${results.demographics?.marriageStatus || ''}</span>
    </div>
  </div>
  
  <div class="section">
    <h2>Overall Score</h2>
    <div class="score-item">
      <span>Total Score:</span>
      <span>${results.totalScore || 0} / ${results.maxPossibleScore || 100} (${Math.round(((results.totalScore || 0) / (results.maxPossibleScore || 100)) * 100)}%)</span>
    </div>
    <div class="score-bar" style="width: ${Math.round(((results.totalScore || 0) / (results.maxPossibleScore || 100)) * 100)}%;"></div>
    
    <div class="scale">
      <div class="scale-item">0%</div>
      <div class="scale-item">25%</div>
      <div class="scale-item">50%</div>
      <div class="scale-item">75%</div>
      <div class="scale-item">100%</div>
    </div>
  </div>
  
  <div class="footer">
    <p>This assessment is designed to help you understand your relationship preferences and compatibility factors.</p>
    <p>© 2025 Lawrence E. Adjah</p>
  </div>
</body>
</html>`;
  
  return html;
};

export default generateEmailReport;
