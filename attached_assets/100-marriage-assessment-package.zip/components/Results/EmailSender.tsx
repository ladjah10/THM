import React, { useState } from 'react';
import axios from 'axios';
import './EmailSender.css';

// Import the email template generator as a regular import
const generateEmailReport = require('./EmailReportTemplate');

interface EmailSenderProps {
  results: any;
  profile: any;
  onClose: () => void;
}

const EmailSender: React.FC<EmailSenderProps> = ({ results, profile, onClose }) => {
  const [email, setEmail] = useState(results.demographics.email || '');
  const [sending, setSending] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setError('Please enter a valid email address');
      return;
    }

    setSending(true);
    setError('');
    
    try {
      // Add profile to results for email generation
      const resultsWithProfile = {
        ...results,
        profile: profile
      };
      
      // Generate HTML email content
      const emailContent = generateEmailReport(resultsWithProfile);
      
      // Send email with results
      const response = await axios.post('/api/email/send', {
        to: email,
        cc: 'la@lawrenceadjah.com', // Always CC Lawrence Adjah
        subject: 'Your 100 Marriage Assessment Results',
        html: emailContent,
        attachments: [] // Could add PDF attachments if needed
      });
      
      if (response.data.success) {
        setSuccess(true);
        setTimeout(() => {
          onClose();
        }, 3000);
      } else {
        throw new Error(response.data.message || 'Failed to send email');
      }
    } catch (err) {
      console.error('Error sending email:', err);
      setError('Failed to send email. Please try again later.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="email-sender-overlay">
      <div className="email-sender-container">
        <button className="close-button" onClick={onClose}>×</button>
        
        <h3>Email Your Assessment Results</h3>
        
        {success ? (
          <div className="success-message">
            <p>Your results have been successfully sent to {email}!</p>
            <p>A copy has also been sent to Lawrence Adjah (la@lawrenceadjah.com).</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {error && <div className="error-message">{error}</div>}
            
            <div className="form-group">
              <label htmlFor="email">Email Address:</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div className="email-info">
              <p>Your assessment results will be sent to the email address you provide.</p>
              <p>A copy will also be sent to Lawrence Adjah (la@lawrenceadjah.com).</p>
            </div>
            
            <div className="form-actions">
              <button 
                type="button" 
                className="cancel-button"
                onClick={onClose}
                disabled={sending}
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="send-button"
                disabled={sending}
              >
                {sending ? 'Sending...' : 'Send Results'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default EmailSender;
