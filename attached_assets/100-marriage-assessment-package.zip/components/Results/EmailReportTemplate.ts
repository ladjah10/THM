// Email report template generator
interface EmailReportData {
  userName: string;
  assessmentDate: string;
  totalScore: number;
  maxScore: number;
  percentile: number;
  profileName: string;
  profileData: {
    description: string;
    traits: string[];
    strengths: string[];
    weaknesses: string[];
  };
  answers: Record<string, string>;
}

const generateEmailReport = (data: EmailReportData): string => {
  const {
    userName,
    assessmentDate,
    totalScore,
    maxScore,
    percentile,
    profileName,
    profileData,
    answers
  } = data;

  // Calculate score percentage
  const scorePercentage = (totalScore / maxScore) * 100;
  
  // Generate score interpretation
  const getScoreInterpretation = (percentage: number): string => {
    if (percentage >= 90) {
      return "Exceptional alignment with assessment criteria. Your responses indicate an outstanding match with the core principles measured in this assessment.";
    } else if (percentage >= 80) {
      return "Very strong alignment with assessment criteria. Your responses show a high degree of compatibility with the core principles measured.";
    } else if (percentage >= 70) {
      return "Strong alignment with assessment criteria. Your responses indicate good compatibility with most core principles measured.";
    } else if (percentage >= 60) {
      return "Moderate alignment with assessment criteria. Your responses show compatibility with many core principles, with some areas for growth.";
    } else if (percentage >= 50) {
      return "Average alignment with assessment criteria. Your responses indicate a balanced mix of strengths and areas for development.";
    } else {
      return "Below average alignment with assessment criteria. Your responses suggest several areas where growth and development could enhance compatibility.";
    }
  };

  // Generate question responses HTML
  const generateQuestionResponsesHTML = (): string => {
    let html = '';
    
    // Import questions from the questions module
    const { questions } = require('../Questionnaire/questions');
    
    Object.entries(answers).forEach(([questionId, answerValue]) => {
      const question = questions.find((q: any) => q.id === parseInt(questionId, 10));
      if (!question) return;
      
      const selectedOption = question.options.find((opt: any) => opt.value === answerValue);
      const optionLabel = selectedOption ? selectedOption.label : 'No response';
      const points = selectedOption ? selectedOption.points : 0;
      
      html += `
        <tr>
          <td>${question.text}</td>
          <td>${optionLabel}</td>
          <td>${points}</td>
        </tr>
      `;
    });
    
    return html;
  };

  // Generate traits, strengths, and weaknesses lists
  const generateListItems = (items: string[]): string => {
    return items.map(item => `<li>${item}</li>`).join('');
  };

  // Calculate heights for chart visualization (max height 200px)
  const scoreHeight = Math.min(200, (totalScore / maxScore) * 200);
  const percentileHeight = Math.min(200, (percentile / 100) * 200);

  // Generate the HTML email template
  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The 100 Marriage Assessment - Series 1</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header h1 {
            color: #2c3e50;
            margin-bottom: 5px;
        }
        .header p {
            color: #7f8c8d;
            font-size: 16px;
        }
        .section {
            margin-bottom: 40px;
        }
        .section-header {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        .section-description {
            background-color: #f2f2f2;
            padding: 10px;
            border: 1px solid #ddd;
            margin-bottom: 20px;
        }
        .chart-container {
            display: flex;
            justify-content: space-around;
            margin-bottom: 30px;
        }
        .chart {
            text-align: center;
            width: 45%;
        }
        .chart-title {
            font-weight: bold;
            margin-bottom: 10px;
        }
        .bar-chart {
            height: 200px;
            position: relative;
            margin: 0 auto;
            width: 100px;
            background-color: #3498db;
            border-radius: 5px 5px 0 0;
        }
        .score-label {
            position: absolute;
            top: -25px;
            left: 0;
            right: 0;
            font-size: 18px;
            font-weight: bold;
        }
        .interpretation {
            background-color: #f8f9fa;
            padding: 15px;
            border-left: 4px solid #3498db;
            margin-bottom: 20px;
        }
        .scale {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            padding: 10px;
            background-color: #f2f2f2;
        }
        .scale-item {
            text-align: center;
            width: 20%;
        }
        .scale-label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .scale-value {
            font-size: 14px;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .items-table th, .items-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .items-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .items-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .profile {
            background-color: #e8f4fc;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
        }
        .profile h3 {
            color: #2980b9;
            margin-top: 0;
        }
        .traits-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        .traits-column {
            width: 30%;
        }
        .traits-title {
            font-weight: bold;
            margin-bottom: 10px;
            color: #2980b9;
        }
        .traits-list {
            list-style-type: none;
            padding-left: 0;
        }
        .traits-list li {
            margin-bottom: 5px;
            padding-left: 20px;
            position: relative;
        }
        .traits-list li:before {
            content: "•";
            position: absolute;
            left: 0;
            color: #2980b9;
        }
        .footer {
            text-align: center;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #7f8c8d;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>The 100 Marriage Assessment - Series 1</h1>
        <p>Assessment Results for: ${userName}</p>
        <p>Date: ${assessmentDate}</p>
    </div>

    <div class="section">
        <div class="section-header">Overall Score</div>
        <div class="section-description">
            Your overall score is based on your responses to all 59 questions in the assessment, with faith (Q1) weighted at 36 points.
        </div>
        
        <div class="chart-container">
            <div class="chart">
                <div class="chart-title">Your Score</div>
                <div class="bar-chart" style="height: ${scoreHeight}px;">
                    <div class="score-label">${totalScore}</div>
                </div>
            </div>
            <div class="chart">
                <div class="chart-title">Percentile Ranking</div>
                <div class="bar-chart" style="height: ${percentileHeight}px; background-color: #27ae60;">
                    <div class="score-label">${percentile.toFixed(1)}%</div>
                </div>
            </div>
        </div>
        
        <div class="interpretation">
            <strong>Score Interpretation:</strong>
            <p>${getScoreInterpretation(scorePercentage)}</p>
        </div>
    </div>

    <div class="section">
        <div class="section-header">Psychographic Profile</div>
        <div class="section-description">
            Based on your assessment responses, your psychographic profile has been identified as:
        </div>
        
        <div class="profile">
            <h3>${profileName}</h3>
            <p>${profileData.description}</p>
            
            <div class="traits-container">
                <div class="traits-column">
                    <div class="traits-title">Key Traits:</div>
                    <ul class="traits-list">
                        ${generateListItems(profileData.traits)}
                    </ul>
                </div>
                <div class="traits-column">
                    <div class="traits-title">Strengths:</div>
                    <ul class="traits-list">
                        ${generateListItems(profileData.strengths)}
                    </ul>
                </div>
                <div class="traits-column">
                    <div class="traits-title">Growth Areas:</div>
                    <ul class="traits-list">
                        ${generateListItems(profileData.weaknesses)}
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="section-header">Question Responses</div>
        <div class="section-description">
            Below is a detailed breakdown of your responses to each question in the assessment.
        </div>
        
        <div class="scale">
            <div class="scale-item">
                <div class="scale-label">Strongly Disagree</div>
                <div class="scale-value">1</div>
            </div>
            <div class="scale-item">
                <div class="scale-label">Disagree</div>
                <div class="scale-value">2</div>
            </div>
            <div class="scale-item">
                <div class="scale-label">Undecided</div>
                <div class="scale-value">3</div>
            </div>
            <div class="scale-item">
                <div class="scale-label">Agree</div>
                <div class="scale-value">4</div>
            </div>
            <div class="scale-item">
                <div class="scale-label">Strongly Agree</div>
                <div class="scale-value">5</div>
            </div>
        </div>
        
        <table class="items-table">
            <tr>
                <th>Question</th>
                <th>Your Response</th>
                <th>Points</th>
            </tr>
            ${generateQuestionResponsesHTML()}
        </table>
    </div>

    <div class="footer">
        <p>© 2025 Lawrence E. Adjah</p>
        <p>This report is confidential and intended only for the recipient. Please do not share without permission.</p>
    </div>
</body>
</html>
  `;
};

export default generateEmailReport;
