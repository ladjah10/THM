import React from 'react';

// Psychographic profiles based on the requirements
const profiles = {
  unisex: [
    {
      id: 'steadfast_believers',
      name: 'Steadfast Believers',
      description: 'You prioritize faith as the foundation of your relationship and view marriage as a sacred covenant. You believe in traditional gender roles and are committed to raising children in the faith.',
      characteristics: [
        'Strong faith commitment',
        'Traditional values',
        'Family-oriented',
        'Committed to lifelong marriage',
        'Prioritizes spiritual growth'
      ],
      scoreRanges: {
        faithScore: { min: 30, max: 36 },
        totalScore: { min: 80, max: 100 }
      }
    },
    {
      id: 'harmonious_planners',
      name: 'Harmonious Planners',
      description: 'You value balance, preparation, and intentionality in your relationship. You believe in equal partnership while maintaining clear boundaries and expectations for your marriage.',
      characteristics: [
        'Organized and methodical',
        'Values clear communication',
        'Believes in equal partnership',
        'Plans ahead for challenges',
        'Seeks balance in all areas'
      ],
      scoreRanges: {
        faithScore: { min: 20, max: 29 },
        totalScore: { min: 70, max: 89 }
      }
    },
    {
      id: 'flexible_faithful',
      name: 'Flexible Faithful',
      description: 'You maintain a strong faith foundation while adapting to modern relationship dynamics. You value compromise and flexibility within the framework of your core beliefs.',
      characteristics: [
        'Adaptable while maintaining core values',
        'Open to compromise',
        'Values both tradition and innovation',
        'Seeks growth through challenges',
        'Balances faith with practicality'
      ],
      scoreRanges: {
        faithScore: { min: 15, max: 25 },
        totalScore: { min: 60, max: 79 }
      }
    },
    {
      id: 'pragmatic_partners',
      name: 'Pragmatic Partners',
      description: 'You approach marriage with a practical mindset, focusing on compatibility and shared goals. While faith plays a role, you equally value practical considerations in building your life together.',
      characteristics: [
        'Practical approach to relationship',
        'Values compatibility and shared goals',
        'Balances faith with other priorities',
        'Solution-oriented',
        'Focuses on building a stable future'
      ],
      scoreRanges: {
        faithScore: { min: 10, max: 20 },
        totalScore: { min: 50, max: 69 }
      }
    },
    {
      id: 'individualist_seekers',
      name: 'Individualist Seekers',
      description: 'You value personal growth and autonomy within your relationship. While you appreciate the spiritual dimension of marriage, you prioritize individual fulfillment and mutual support.',
      characteristics: [
        'Values personal autonomy',
        'Seeks spiritual meaning individually',
        'Prioritizes mutual growth and support',
        'Flexible approach to traditions',
        'Values authenticity over conformity'
      ],
      scoreRanges: {
        faithScore: { min: 0, max: 15 },
        totalScore: { min: 0, max: 59 }
      }
    }
  ],
  women: [
    {
      id: 'relational_nurturers',
      name: 'Relational Nurturers',
      description: 'You prioritize emotional connection and nurturing relationships. You see your role as creating a warm, supportive home environment while maintaining your faith values.',
      characteristics: [
        'Emotionally intuitive',
        'Nurturing and supportive',
        'Values deep connection',
        'Creates harmonious home environment',
        'Balances strength with tenderness'
      ],
      scoreRanges: {
        faithScore: { min: 25, max: 36 },
        totalScore: { min: 75, max: 100 }
      }
    },
    {
      id: 'adaptive_communicators',
      name: 'Adaptive Communicators',
      description: 'You excel at bridging different perspectives and facilitating healthy communication. You adapt to changing circumstances while maintaining your core values and faith.',
      characteristics: [
        'Excellent communicator',
        'Adaptable to change',
        'Mediates conflicts effectively',
        'Balances tradition with flexibility',
        'Builds bridges between different viewpoints'
      ],
      scoreRanges: {
        faithScore: { min: 15, max: 29 },
        totalScore: { min: 60, max: 79 }
      }
    },
    {
      id: 'independent_traditionalists',
      name: 'Independent Traditionalists',
      description: 'You value traditional marriage roles while maintaining your independence and voice. You believe in honoring faith traditions while asserting your unique strengths and perspectives.',
      characteristics: [
        'Values traditional roles with modern adaptations',
        'Maintains independence within relationship',
        'Strong personal convictions',
        'Balances submission with self-assertion',
        'Values both tradition and personal growth'
      ],
      scoreRanges: {
        faithScore: { min: 20, max: 30 },
        totalScore: { min: 65, max: 85 }
      }
    }
  ],
  men: [
    {
      id: 'faithful_protectors',
      name: 'Faithful Protectors',
      description: 'You see yourself as the spiritual leader and protector of your family. You take seriously your responsibility to provide, guide, and safeguard your marriage and family.',
      characteristics: [
        'Strong sense of responsibility',
        'Protective of family',
        'Values spiritual leadership role',
        'Committed provider',
        'Principled decision-maker'
      ],
      scoreRanges: {
        faithScore: { min: 25, max: 36 },
        totalScore: { min: 75, max: 100 }
      }
    },
    {
      id: 'structured_leaders',
      name: 'Structured Leaders',
      description: 'You value order, clarity, and defined roles in your relationship. You lead through establishing clear expectations and creating systems that support your family's values and goals.',
      characteristics: [
        'Organized and structured',
        'Clear about expectations',
        'Values defined roles',
        'Strategic planner',
        'Consistent and reliable'
      ],
      scoreRanges: {
        faithScore: { min: 20, max: 30 },
        totalScore: { min: 65, max: 85 }
      }
    }
  ]
};

// Function to determine the psychographic profile based on scores and gender
export const getPsychographicProfile = (scores, gender) => {
  // Extract faith score (Q1) and total score
  const faithScore = scores?.faith || 0;
  const totalScore = scores?.total || 0;
  
  // Determine which profile sets to check based on gender
  let profileSets = ['unisex'];
  if (gender === 'Male') {
    profileSets.push('men');
  } else if (gender === 'Female') {
    profileSets.push('women');
  }
  
  // Check each applicable profile set
  for (const setName of profileSets) {
    const profileSet = profiles[setName];
    
    // Check each profile in the set
    for (const profile of profileSet) {
      const { scoreRanges } = profile;
      
      // Check if scores fall within this profile's ranges
      if (
        faithScore >= scoreRanges.faithScore.min && 
        faithScore <= scoreRanges.faithScore.max &&
        totalScore >= scoreRanges.totalScore.min && 
        totalScore <= scoreRanges.totalScore.max
      ) {
        return profile;
      }
    }
  }
  
  // Default to first unisex profile if no match found
  return profiles.unisex[0];
};

export default profiles;
