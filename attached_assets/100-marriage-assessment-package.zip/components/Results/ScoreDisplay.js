// Score calculation and display functionality
import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, LinearProgress, Grid, Container } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Define the scoring weights for each question
const questionWeights = {
  1: 36, // Faith question worth 36 points
  // Other questions with their respective weights
  2: 3,
  3: 3,
  4: 3,
  5: 3,
  6: 3,
  7: 3,
  8: 3,
  9: 3,
  10: 3,
  // ... remaining questions
};

// Define the psychographic profiles
const psychographicProfiles = {
  // Unisex profiles
  "Steadfast Believers": {
    description: "Individuals who prioritize faith above all else in relationships, seeking partners with similar strong religious convictions.",
    traits: ["Faith-centered", "Traditional", "Principled", "Community-oriented", "Devoted"],
    strengths: ["Strong moral compass", "Commitment to values", "Spiritual connection", "Relationship stability"],
    weaknesses: ["May struggle with differences", "Potential rigidity", "Possible judgment of others"]
  },
  "Harmonious Planners": {
    description: "Methodical individuals who value both faith and practical planning in relationships, seeking balance and harmony.",
    traits: ["Balanced", "Organized", "Thoughtful", "Practical", "Harmonious"],
    strengths: ["Good at compromise", "Financial planning", "Long-term thinking", "Stability"],
    weaknesses: ["May overthink decisions", "Occasional inflexibility", "Perfectionism"]
  },
  "Flexible Faithful": {
    description: "Adaptable individuals with moderate faith importance who value compromise and growth in relationships.",
    traits: ["Adaptable", "Moderate faith", "Growth-oriented", "Communicative", "Open-minded"],
    strengths: ["Flexibility", "Good listening skills", "Willingness to evolve", "Acceptance of differences"],
    weaknesses: ["May lack strong convictions", "Potential indecisiveness", "Occasional conflict avoidance"]
  },
  "Pragmatic Partners": {
    description: "Practical individuals who approach relationships with a focus on compatibility and shared goals rather than faith alone.",
    traits: ["Practical", "Goal-oriented", "Rational", "Independent", "Collaborative"],
    strengths: ["Problem-solving skills", "Realistic expectations", "Self-sufficiency", "Adaptability"],
    weaknesses: ["May undervalue emotional aspects", "Potential lack of spontaneity", "Occasional detachment"]
  },
  "Individualist Seekers": {
    description: "Independent thinkers who prioritize personal growth and exploration in relationships, with faith as a personal journey.",
    traits: ["Independent", "Questioning", "Growth-focused", "Explorative", "Introspective"],
    strengths: ["Self-awareness", "Intellectual curiosity", "Personal development", "Authenticity"],
    weaknesses: ["May struggle with commitment", "Potential inconsistency", "Occasional self-focus"]
  },
  
  // Women-specific profiles
  "Relational Nurturers": {
    description: "Women who prioritize emotional connection and caregiving in relationships, with faith as a supportive foundation.",
    traits: ["Nurturing", "Emotionally intelligent", "Supportive", "Empathetic", "Community-minded"],
    strengths: ["Deep emotional connections", "Supportive presence", "Intuitive understanding", "Relationship building"],
    weaknesses: ["May neglect self-care", "Potential over-accommodation", "Difficulty setting boundaries"]
  },
  "Adaptive Communicators": {
    description: "Women who excel at navigating relationship dynamics through communication, with moderate faith importance.",
    traits: ["Communicative", "Adaptable", "Perceptive", "Diplomatic", "Balanced"],
    strengths: ["Conflict resolution", "Emotional articulation", "Perspective-taking", "Relationship maintenance"],
    weaknesses: ["May avoid difficult conversations", "Potential people-pleasing", "Occasional indirectness"]
  },
  "Independent Traditionalists": {
    description: "Women who value both independence and traditional relationship structures, with faith as a guiding principle.",
    traits: ["Independent", "Traditional", "Self-assured", "Principled", "Structured"],
    strengths: ["Clear boundaries", "Self-sufficiency", "Value clarity", "Relationship stability"],
    weaknesses: ["May struggle with vulnerability", "Potential rigidity", "Occasional difficulty compromising"]
  },
  
  // Men-specific profiles
  "Faithful Protectors": {
    description: "Men who see themselves as providers and protectors, with faith as a central guiding force in relationships.",
    traits: ["Protective", "Faith-centered", "Responsible", "Committed", "Steadfast"],
    strengths: ["Reliability", "Sense of purpose", "Protective nature", "Moral clarity"],
    weaknesses: ["May be overly traditional", "Potential inflexibility", "Occasional difficulty expressing emotions"]
  },
  "Structured Leaders": {
    description: "Men who approach relationships with a focus on leadership and structure, with faith as a framework for decision-making.",
    traits: ["Structured", "Goal-oriented", "Decisive", "Principled", "Methodical"],
    strengths: ["Decision-making ability", "Clear direction", "Consistency", "Reliability"],
    weaknesses: ["May be controlling", "Potential difficulty with emotional aspects", "Occasional stubbornness"]
  }
};

// Function to determine psychographic profile based on scores and gender
const determineProfile = (scores, gender) => {
  // Calculate total score
  const totalScore = Object.keys(scores).reduce((sum, questionId) => {
    return sum + (scores[questionId] * (questionWeights[questionId] || 3));
  }, 0);
  
  // Calculate maximum possible score
  const maxScore = Object.keys(scores).reduce((sum, questionId) => {
    return sum + (5 * (questionWeights[questionId] || 3)); // 5 is max score per question
  }, 0);
  
  // Calculate percentage score
  const percentageScore = (totalScore / maxScore) * 100;
  
  // Faith importance (Q1 score)
  const faithScore = scores[1] || 3;
  
  // Determine profile based on scores and gender
  let profile;
  
  if (faithScore >= 4.5) {
    // High faith importance
    if (gender === 'female') {
      if (percentageScore >= 80) {
        profile = "Relational Nurturers";
      } else {
        profile = "Steadfast Believers";
      }
    } else if (gender === 'male') {
      if (percentageScore >= 80) {
        profile = "Faithful Protectors";
      } else {
        profile = "Steadfast Believers";
      }
    } else {
      profile = "Steadfast Believers";
    }
  } else if (faithScore >= 3.5) {
    // Moderate faith importance
    if (gender === 'female') {
      if (percentageScore >= 75) {
        profile = "Adaptive Communicators";
      } else {
        profile = "Harmonious Planners";
      }
    } else if (gender === 'male') {
      if (percentageScore >= 75) {
        profile = "Structured Leaders";
      } else {
        profile = "Harmonious Planners";
      }
    } else {
      profile = "Harmonious Planners";
    }
  } else if (faithScore >= 2.5) {
    // Lower moderate faith importance
    if (gender === 'female') {
      if (percentageScore >= 70) {
        profile = "Independent Traditionalists";
      } else {
        profile = "Flexible Faithful";
      }
    } else if (gender === 'male') {
      if (percentageScore >= 70) {
        profile = "Structured Leaders";
      } else {
        profile = "Flexible Faithful";
      }
    } else {
      profile = "Flexible Faithful";
    }
  } else {
    // Low faith importance
    if (percentageScore >= 65) {
      profile = "Pragmatic Partners";
    } else {
      profile = "Individualist Seekers";
    }
  }
  
  return {
    profileName: profile,
    profileData: psychographicProfiles[profile],
    totalScore,
    percentageScore,
    maxScore
  };
};

// Score Display Component
const ScoreDisplay = ({ scores, gender, onSendEmail }) => {
  const [profileResult, setProfileResult] = useState(null);
  
  useEffect(() => {
    if (scores && Object.keys(scores).length > 0) {
      const result = determineProfile(scores, gender);
      setProfileResult(result);
    }
  }, [scores, gender]);
  
  if (!profileResult) {
    return <Typography>Loading results...</Typography>;
  }
  
  const { profileName, profileData, totalScore, percentageScore, maxScore } = profileResult;
  
  // Data for score chart
  const scoreChartData = [
    {
      name: 'Your Score',
      score: totalScore,
      fill: '#3498db'
    },
    {
      name: 'Maximum Score',
      score: maxScore,
      fill: '#2ecc71'
    }
  ];
  
  // Interpret score
  const getScoreInterpretation = (percentage) => {
    if (percentage >= 90) {
      return "Exceptional alignment with assessment criteria. Your responses indicate an outstanding match with the core principles measured in this assessment.";
    } else if (percentage >= 80) {
      return "Very strong alignment with assessment criteria. Your responses show a high degree of compatibility with the core principles measured.";
    } else if (percentage >= 70) {
      return "Strong alignment with assessment criteria. Your responses indicate good compatibility with most core principles measured.";
    } else if (percentage >= 60) {
      return "Moderate alignment with assessment criteria. Your responses show compatibility with many core principles, with some areas for growth.";
    } else if (percentage >= 50) {
      return "Average alignment with assessment criteria. Your responses indicate a balanced mix of strengths and areas for development.";
    } else {
      return "Below average alignment with assessment criteria. Your responses suggest several areas where growth and development could enhance compatibility.";
    }
  };
  
  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          The 100 Marriage Assessment - Series 1
        </Typography>
        <Typography variant="subtitle1" gutterBottom align="center">
          Assessment Results
        </Typography>
        
        {/* Overall Score Section */}
        <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
          <Typography variant="h5" gutterBottom align="center">
            Overall Score
          </Typography>
          
          <Box sx={{ mb: 3 }}>
            <Typography variant="body1" gutterBottom>
              Your score: {totalScore} out of {maxScore} ({percentageScore.toFixed(1)}%)
            </Typography>
            <LinearProgress 
              variant="determinate" 
              value={percentageScore} 
              sx={{ height: 20, borderRadius: 5 }}
            />
          </Box>
          
          <Box sx={{ height: 300, mb: 3 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={scoreChartData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="score" name="Score" />
              </BarChart>
            </ResponsiveContainer>
          </Box>
          
          <Box sx={{ bgcolor: '#f5f5f5', p: 2, borderRadius: 1 }}>
            <Typography variant="subtitle1" gutterBottom fontWeight="bold">
              Score Interpretation:
            </Typography>
            <Typography variant="body1">
              {getScoreInterpretation(percentageScore)}
            </Typography>
          </Box>
        </Paper>
        
        {/* Psychographic Profile Section */}
        <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
          <Typography variant="h5" gutterBottom align="center">
            Your Psychographic Profile: {profileName}
          </Typography>
          
          <Typography variant="body1" paragraph>
            {profileData.description}
          </Typography>
          
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <Box sx={{ bgcolor: '#e3f2fd', p: 2, borderRadius: 1, height: '100%' }}>
                <Typography variant="subtitle1" gutterBottom fontWeight="bold">
                  Key Traits:
                </Typography>
                <ul>
                  {profileData.traits.map((trait, index) => (
                    <li key={index}>{trait}</li>
                  ))}
                </ul>
              </Box>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Box sx={{ bgcolor: '#e8f5e9', p: 2, borderRadius: 1, height: '100%' }}>
                <Typography variant="subtitle1" gutterBottom fontWeight="bold">
                  Strengths:
                </Typography>
                <ul>
                  {profileData.strengths.map((strength, index) => (
                    <li key={index}>{strength}</li>
                  ))}
                </ul>
              </Box>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Box sx={{ bgcolor: '#fff3e0', p: 2, borderRadius: 1, height: '100%' }}>
                <Typography variant="subtitle1" gutterBottom fontWeight="bold">
                  Growth Areas:
                </Typography>
                <ul>
                  {profileData.weaknesses.map((weakness, index) => (
                    <li key={index}>{weakness}</li>
                  ))}
                </ul>
              </Box>
            </Grid>
          </Grid>
          
          <Box sx={{ mt: 3, textAlign: 'center' }}>
            <button 
              onClick={onSendEmail}
              style={{
                padding: '10px 20px',
                backgroundColor: '#2c3e50',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                fontSize: '16px',
                cursor: 'pointer'
              }}
            >
              Send Detailed Report to My Email
            </button>
          </Box>
        </Paper>
        
        <Box sx={{ textAlign: 'center', mt: 4, color: '#7f8c8d', fontSize: '14px' }}>
          © 2025 Lawrence E. Adjah
        </Box>
      </Box>
    </Container>
  );
};

export default ScoreDisplay;
