import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Button, 
  CircularProgress, 
  Alert,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ScoreDisplay from '../Results/ScoreDisplay';

// Email service component
const EmailService: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [email, setEmail] = useState('');
  const [open, setOpen] = useState(false);
  
  const navigate = useNavigate();
  
  // Check if user is logged in
  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!isLoggedIn) {
      navigate('/login');
    }
    
    // Get current user email
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    if (currentUser.email) {
      setEmail(currentUser.email);
    }
  }, [navigate]);
  
  const handleSendEmail = () => {
    setLoading(true);
    setError('');
    
    try {
      // Get current user
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      
      // Get answers
      const answers = JSON.parse(localStorage.getItem(`answers_${currentUser.id}`) || '{}');
      
      // Prepare email data
      const emailData = {
        to: email,
        cc: 'la@lawrenceadjah.com',
        subject: 'Your 100 Marriage Assessment Results',
        userName: `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim() || email,
        assessmentDate: new Date().toLocaleDateString(),
        totalScore: currentUser.totalScore,
        maxScore: currentUser.maxScore,
        percentile: currentUser.percentile,
        profileName: currentUser.profileName,
        answers: answers
      };
      
      // Store email data in localStorage for demonstration
      localStorage.setItem(`emailReport_${currentUser.id}`, JSON.stringify(emailData));
      
      // Simulate API delay
      setTimeout(() => {
        setSuccess(true);
        setLoading(false);
        setOpen(false);
      }, 1500);
      
    } catch (err: any) {
      console.error('Email sending error:', err);
      setError('Failed to send email. Please try again.');
      setLoading(false);
    }
  };
  
  const handleClickOpen = () => {
    setOpen(true);
  };
  
  const handleClose = () => {
    setOpen(false);
  };
  
  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4, textAlign: 'center' }}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 2 }}>Your detailed report has been sent to your email address!</Alert>}
        
        <Button 
          variant="contained" 
          color="primary" 
          onClick={handleClickOpen}
          disabled={loading || success}
          sx={{ py: 1, px: 3 }}
        >
          {loading ? <CircularProgress size={24} /> : 'Send Detailed Report to My Email'}
        </Button>
        
        <Dialog open={open} onClose={handleClose}>
          <DialogTitle>Send Assessment Report</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Enter your email address to receive a detailed report of your assessment results.
              Lawrence E. Adjah (la@lawrenceadjah.com) will be CC'd on this email.
            </DialogContentText>
            <TextField
              autoFocus
              margin="dense"
              id="email"
              label="Email Address"
              type="email"
              fullWidth
              variant="outlined"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>Cancel</Button>
            <Button 
              onClick={handleSendEmail} 
              disabled={!email || loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Send Report'}
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
};

export default EmailService;
