// Simple email report template as a plain string
const generateEmailReport = function(results) {
  return "<!DOCTYPE html><html><head><title>Your 100 Marriage Assessment Results</title></head><body><h1>Your 100 Marriage Assessment Results</h1><p>© 2025 Lawrence E. Adjah</p></body></html>";
};

module.exports = generateEmailReport;
