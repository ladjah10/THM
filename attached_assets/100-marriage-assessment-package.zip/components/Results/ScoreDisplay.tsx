import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './ScoreDisplay.css';
import { getPsychographicProfile } from './psychographicProfiles';
import EmailSender from './EmailSender';

// Import the email template generator as a regular import
const generateEmailReport = require('./EmailReportTemplate');

const ScoreDisplay = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [results, setResults] = useState(null);
  const [profile, setProfile] = useState(null);
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [reportHtml, setReportHtml] = useState('');
  const [showPrintableView, setShowPrintableView] = useState(false);

  useEffect(() => {
    // Get results from location state or fetch from API if needed
    if (location.state?.results) {
      setResults(location.state.results);
      
      // Determine psychographic profile based on scores
      const userProfile = getPsychographicProfile(location.state.results.scores, location.state.results.demographics.gender);
      setProfile(userProfile);
      
      // Generate HTML report for on-screen display
      const resultsWithProfile = {
        ...location.state.results,
        profile: userProfile
      };
      const html = generateEmailReport(resultsWithProfile);
      setReportHtml(html);
    } else {
      // If no results in location state, redirect to questionnaire
      navigate('/questionnaire');
    }
    
    // Add protection against screenshots and printing
    document.addEventListener('keydown', preventScreenCapture);
    document.addEventListener('contextmenu', preventRightClick);
    
    return () => {
      // Clean up event listeners
      document.removeEventListener('keydown', preventScreenCapture);
      document.removeEventListener('contextmenu', preventRightClick);
    };
  }, [location, navigate]);
  
  // Prevent screen capture using keyboard shortcuts
  const preventScreenCapture = (e) => {
    // Prevent PrintScreen (and other common screenshot shortcuts)
    if (
      (e.key === 'PrintScreen') || 
      (e.ctrlKey && e.key === 'p') || 
      (e.ctrlKey && e.shiftKey && e.key === 'p') ||
      (e.ctrlKey && e.key === 's') ||
      (e.metaKey && e.key === 'p') ||
      (e.metaKey && e.shiftKey && e.key === 'p') ||
      (e.metaKey && e.key === 's')
    ) {
      e.preventDefault();
      alert('Printing and screenshots are disabled for this assessment.');
      return false;
    }
  };
  
  // Prevent right-click context menu
  const preventRightClick = (e) => {
    e.preventDefault();
    return false;
  };

  const renderScoreSection = (sectionName, sectionScores) => {
    const chartData = Object.entries(sectionScores).map(([key, value]) => ({
      name: key,
      score: value
    }));

    return (
      <div className="score-section">
        <h3>{sectionName}</h3>
        <div className="chart-container">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={chartData}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="score" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="score-details">
          {Object.entries(sectionScores).map(([key, value]) => (
            <div key={key} className="score-item">
              <span className="score-label">{key}:</span>
              <span className="score-value">{value}</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderProfileSection = () => {
    if (!profile) return null;

    return (
      <div className="profile-section">
        <h3>Your Psychographic Profile</h3>
        <div className="profile-name">{profile.name}</div>
        <div className="profile-description">{profile.description}</div>
        <div className="profile-characteristics">
          <h4>Key Characteristics:</h4>
          <ul>
            {profile.characteristics.map((char, index) => (
              <li key={index}>{char}</li>
            ))}
          </ul>
        </div>
      </div>
    );
  };

  const handleEmailClick = () => {
    setShowEmailForm(true);
  };
  
  const togglePrintableView = () => {
    setShowPrintableView(!showPrintableView);
  };

  if (!results) {
    return <div className="loading">Loading results...</div>;
  }
  
  // Show the HTML report in an iframe for the printable view
  if (showPrintableView) {
    return (
      <div className="printable-view-container">
        <div className="printable-view-header">
          <button onClick={togglePrintableView}>Back to Interactive View</button>
        </div>
        <iframe 
          title="Assessment Report"
          srcDoc={reportHtml}
          className="report-iframe"
          style={{ width: '100%', height: 'calc(100vh - 60px)', border: 'none' }}
        />
      </div>
    );
  }

  return (
    <div className="score-display-container">
      <h2>Your Assessment Results</h2>
      
      <div className="view-toggle">
        <button onClick={togglePrintableView}>View Full Report</button>
      </div>
      
      <div className="user-info">
        <h3>Personal Information</h3>
        <div className="info-item">
          <span className="info-label">Name:</span>
          <span className="info-value">{results.demographics.firstName} {results.demographics.lastName}</span>
        </div>
        <div className="info-item">
          <span className="info-label">Email:</span>
          <span className="info-value">{results.demographics.email}</span>
        </div>
        <div className="info-item">
          <span className="info-label">Assessment Date:</span>
          <span className="info-value">{new Date().toLocaleDateString()}</span>
        </div>
      </div>

      <div className="overall-score">
        <h3>Overall Score</h3>
        <div className="score-value">{results.totalScore} / {results.maxPossibleScore}</div>
        <div className="score-percentage">{Math.round((results.totalScore / results.maxPossibleScore) * 100)}%</div>
      </div>

      <div className="section-scores">
        <h3>Section Scores</h3>
        {Object.entries(results.sectionScores || {}).map(([section, scores]) => (
          renderScoreSection(section, scores)
        ))}
      </div>

      {renderProfileSection()}

      <div className="question-responses">
        <h3>Your Responses</h3>
        <div className="responses-list">
          {(results.responses || []).map((response) => (
            <div key={response.questionId} className="response-item">
              <div className="question-text">{response.questionText}</div>
              <div className="answer-text">{response.answer}</div>
              <div className="question-weight">Weight: {response.weight}</div>
              <div className="question-score">Score: {response.score}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="action-buttons">
        <button className="email-button" onClick={handleEmailClick}>Email Results</button>
      </div>

      {showEmailForm && (
        <EmailSender 
          results={results} 
          profile={profile}
          onClose={() => setShowEmailForm(false)}
        />
      )}

      <div className="copyright">© 2025 Lawrence E. Adjah</div>
    </div>
  );
};

export default ScoreDisplay;
