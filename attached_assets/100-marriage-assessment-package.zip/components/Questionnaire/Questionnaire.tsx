import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Questionnaire.css';
import demographicQuestionsData from '../../data/demographic_questions.json';
import fullQuestionsData from '../../data/full_questions.json';

// Define section types for TypeScript
interface SectionMap {
  [key: string]: any[];
}

const Questionnaire = () => {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState('demographics');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<{[key: string]: {answer: string, score: number}}>({});
  const [demographics, setDemographics] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    gender: '',
    desireForChildren: '',
    marriageStatus: '',
    raceEthnicity: '',
    datePurchased: new Date().toISOString().split('T')[0]
  });

  // Extract questions arrays from the JSON structures
  const demographicQuestions = demographicQuestionsData.demographicQuestions || [];
  const fullQuestions = fullQuestionsData.questions || [];

  // Group questions by section with proper typing
  const sections: SectionMap = {
    demographics: demographicQuestions,
    foundation: fullQuestions.filter(q => q.section === 'Your Foundation'),
    faith: fullQuestions.filter(q => q.section === 'Your Faith Life'),
    marriage: fullQuestions.filter(q => q.section === 'Your Marriage Life'),
    family: fullQuestions.filter(q => q.section === 'Your Family Life'),
    finances: fullQuestions.filter(q => q.section === 'Your Financial Life'),
    career: fullQuestions.filter(q => q.section === 'Your Career Life'),
    health: fullQuestions.filter(q => q.section === 'Your Health Life'),
    social: fullQuestions.filter(q => q.section === 'Your Social Life'),
    personal: fullQuestions.filter(q => q.section === 'Your Personal Life')
  };

  // Get current questions based on section
  const currentQuestions = sections[currentSection] || [];
  const currentQuestion = currentQuestions[currentQuestionIndex];

  // Handle demographic input changes
  const handleDemographicChange = (field: string, value: string) => {
    setDemographics({
      ...demographics,
      [field]: value
    });
  };

  // Handle answer selection
  const handleAnswerSelect = (questionId: string, answer: string, score: number) => {
    setAnswers({
      ...answers,
      [questionId]: { answer, score }
    });
  };

  // Navigate to next question
  const handleNext = () => {
    if (currentQuestionIndex < currentQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Move to next section
      const sectionKeys = Object.keys(sections);
      const currentSectionIndex = sectionKeys.indexOf(currentSection);
      
      if (currentSectionIndex < sectionKeys.length - 1) {
        setCurrentSection(sectionKeys[currentSectionIndex + 1]);
        setCurrentQuestionIndex(0);
      } else {
        // All questions answered, calculate results
        calculateResults();
      }
    }
  };

  // Navigate to previous question
  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    } else {
      // Move to previous section
      const sectionKeys = Object.keys(sections);
      const currentSectionIndex = sectionKeys.indexOf(currentSection);
      
      if (currentSectionIndex > 0) {
        setCurrentSection(sectionKeys[currentSectionIndex - 1]);
        setCurrentQuestionIndex(sections[sectionKeys[currentSectionIndex - 1]].length - 1);
      }
    }
  };

  // Calculate final results
  const calculateResults = () => {
    // Calculate total score
    let totalScore = 0;
    let maxPossibleScore = 0;
    const responses: any[] = [];
    const sectionScores: {[key: string]: {[key: string]: number}} = {};

    // Process all questions and answers
    Object.keys(sections).forEach(sectionKey => {
      if (sectionKey !== 'demographics') {
        const sectionQuestions = sections[sectionKey];
        let sectionScore = 0;
        let sectionMaxScore = 0;
        
        sectionQuestions.forEach((question: any) => {
          const answer = answers[question.id];
          const weight = question.weight || 1;
          const score = answer ? answer.score * weight : 0;
          
          sectionScore += score;
          sectionMaxScore += 5 * weight; // Max score is 5 per question
          
          totalScore += score;
          maxPossibleScore += 5 * weight;
          
          responses.push({
            questionId: question.id,
            questionText: question.text,
            answer: answer ? answer.answer : 'Not answered',
            score: score,
            weight: weight
          });
          
          // Store section scores
          if (!sectionScores[question.section]) {
            sectionScores[question.section] = {};
          }
          sectionScores[question.section][question.subsection || 'General'] = sectionScore;
        });
      }
    });

    // Prepare results object
    const results = {
      demographics: demographics,
      totalScore: totalScore,
      maxPossibleScore: maxPossibleScore,
      sectionScores: sectionScores,
      responses: responses,
      scores: {
        faith: sectionScores['Your Faith Life'] ? Object.values(sectionScores['Your Faith Life']).reduce((a, b) => a + b, 0) : 0,
        family: sectionScores['Your Family Life'] ? Object.values(sectionScores['Your Family Life']).reduce((a, b) => a + b, 0) : 0,
        finances: sectionScores['Your Financial Life'] ? Object.values(sectionScores['Your Financial Life']).reduce((a, b) => a + b, 0) : 0,
        career: sectionScores['Your Career Life'] ? Object.values(sectionScores['Your Career Life']).reduce((a, b) => a + b, 0) : 0,
        health: sectionScores['Your Health Life'] ? Object.values(sectionScores['Your Health Life']).reduce((a, b) => a + b, 0) : 0,
        social: sectionScores['Your Social Life'] ? Object.values(sectionScores['Your Social Life']).reduce((a, b) => a + b, 0) : 0,
        personal: sectionScores['Your Personal Life'] ? Object.values(sectionScores['Your Personal Life']).reduce((a, b) => a + b, 0) : 0
      }
    };

    // Navigate to results page with results data
    navigate('/results', { state: { results } });
  };

  // Render demographic questions
  const renderDemographicQuestion = () => {
    const question = currentQuestions[currentQuestionIndex];
    
    return (
      <div className="question-container">
        <h3>{question.label || question.text}</h3>
        
        {question.type === 'text' && (
          <input
            type="text"
            value={demographics[question.id as keyof typeof demographics] || ''}
            onChange={(e) => handleDemographicChange(question.id, e.target.value)}
            placeholder={question.placeholder || ''}
            required={question.required}
          />
        )}
        
        {question.type === 'email' && (
          <input
            type="email"
            value={demographics[question.id as keyof typeof demographics] || ''}
            onChange={(e) => handleDemographicChange(question.id, e.target.value)}
            placeholder={question.placeholder || ''}
            required={question.required}
          />
        )}
        
        {question.type === 'tel' && (
          <input
            type="tel"
            value={demographics[question.id as keyof typeof demographics] || ''}
            onChange={(e) => handleDemographicChange(question.id, e.target.value)}
            placeholder={question.placeholder || ''}
            required={question.required}
          />
        )}
        
        {question.type === 'select' && (
          <select
            value={demographics[question.id as keyof typeof demographics] || ''}
            onChange={(e) => handleDemographicChange(question.id, e.target.value)}
            required={question.required}
          >
            <option value="">Select an option</option>
            {question.options && question.options.map((option: any, index: number) => (
              <option key={index} value={typeof option === 'string' ? option : option.value}>
                {typeof option === 'string' ? option : option.label}
              </option>
            ))}
          </select>
        )}
        
        {question.type === 'date' && (
          <input
            type="date"
            value={demographics[question.id as keyof typeof demographics] || ''}
            onChange={(e) => handleDemographicChange(question.id, e.target.value)}
            required={question.required}
          />
        )}
      </div>
    );
  };

  // Render assessment questions
  const renderAssessmentQuestion = () => {
    const question = currentQuestions[currentQuestionIndex];
    const selectedAnswer = answers[question.id];
    
    return (
      <div className="question-container">
        <div className="question-header">
          <span className="question-section">{question.section}</span>
          <span className="question-number">Question {currentQuestionIndex + 1} of {currentQuestions.length}</span>
        </div>
        
        <h3>{question.text}</h3>
        
        {question.type === 'M' && (
          <div className="options-container">
            {question.options && question.options.map((option: any, index: number) => (
              <div 
                key={index} 
                className={`option ${selectedAnswer && selectedAnswer.answer === (typeof option === 'string' ? option : option.text) ? 'selected' : ''}`}
                onClick={() => handleAnswerSelect(question.id, typeof option === 'string' ? option : option.text, typeof option === 'object' && option.score ? option.score : 5)}
              >
                {typeof option === 'string' ? option : option.text}
              </div>
            ))}
          </div>
        )}
        
        {question.type === 'D' && (
          <div className="declaration-container">
            <p className="declaration-text">{question.declaration || question.text}</p>
            <div className="options-container">
              <div 
                className={`option ${selectedAnswer && selectedAnswer.answer === 'I agree' ? 'selected' : ''}`}
                onClick={() => handleAnswerSelect(question.id, 'I agree', 5)}
              >
                I agree
              </div>
              <div 
                className={`option ${selectedAnswer && selectedAnswer.answer === 'I disagree' ? 'selected' : ''}`}
                onClick={() => handleAnswerSelect(question.id, 'I disagree', 1)}
              >
                I disagree
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Render progress bar
  const renderProgressBar = () => {
    const sectionKeys = Object.keys(sections);
    const totalQuestions = sectionKeys.reduce((total, key) => total + sections[key].length, 0);
    
    // Calculate completed questions
    let completedQuestions = 0;
    sectionKeys.forEach((key, sectionIndex) => {
      const sectionQuestions = sections[key];
      if (sectionIndex < sectionKeys.indexOf(currentSection)) {
        completedQuestions += sectionQuestions.length;
      } else if (key === currentSection) {
        completedQuestions += currentQuestionIndex;
      }
    });
    
    const progressPercentage = (completedQuestions / totalQuestions) * 100;
    
    return (
      <div className="progress-container">
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${progressPercentage}%` }}></div>
        </div>
        <div className="progress-text">
          {completedQuestions} of {totalQuestions} questions completed ({Math.round(progressPercentage)}%)
        </div>
      </div>
    );
  };

  return (
    <div className="questionnaire-container">
      <h2>The 100 Marriage Assessment - Series 1</h2>
      
      {renderProgressBar()}
      
      {currentSection === 'demographics' ? renderDemographicQuestion() : renderAssessmentQuestion()}
      
      <div className="navigation-buttons">
        <button 
          className="previous-button" 
          onClick={handlePrevious}
          disabled={currentSection === 'demographics' && currentQuestionIndex === 0}
        >
          Previous
        </button>
        
        <button 
          className="next-button" 
          onClick={handleNext}
          disabled={
            (currentSection === 'demographics' && !demographics[currentQuestions[currentQuestionIndex].id as keyof typeof demographics]) ||
            (currentSection !== 'demographics' && !answers[currentQuestions[currentQuestionIndex].id])
          }
        >
          {currentSection === Object.keys(sections)[Object.keys(sections).length - 1] && 
           currentQuestionIndex === currentQuestions.length - 1 ? 'Submit' : 'Next'}
        </button>
      </div>
      
      <div className="copyright">© 2025 Lawrence E. Adjah</div>
    </div>
  );
};

export default Questionnaire;
